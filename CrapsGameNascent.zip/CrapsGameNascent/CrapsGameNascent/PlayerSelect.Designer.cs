﻿namespace CrapsGameNascent
{
    partial class PlayerSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_blank = new System.Windows.Forms.Label();
            this.dg_Players = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.txt_Name = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_showPlayers = new System.Windows.Forms.Button();
            this.btn_Edit = new System.Windows.Forms.Button();
            this.btn_Next = new System.Windows.Forms.Button();
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_selectPlayer = new System.Windows.Forms.Button();
            this.lbl_Id = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Players)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_blank
            // 
            this.lbl_blank.AutoSize = true;
            this.lbl_blank.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_blank.Location = new System.Drawing.Point(12, 14);
            this.lbl_blank.Name = "lbl_blank";
            this.lbl_blank.Size = new System.Drawing.Size(71, 24);
            this.lbl_blank.TabIndex = 0;
            this.lbl_blank.Text = "Players";
            this.lbl_blank.Click += new System.EventHandler(this.label1_Click);
            // 
            // dg_Players
            // 
            this.dg_Players.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Players.Location = new System.Drawing.Point(15, 107);
            this.dg_Players.Name = "dg_Players";
            this.dg_Players.Size = new System.Drawing.Size(489, 215);
            this.dg_Players.TabIndex = 1;
            this.dg_Players.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(409, 64);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(59, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txt_Name
            // 
            this.txt_Name.Location = new System.Drawing.Point(371, 14);
            this.txt_Name.Name = "txt_Name";
            this.txt_Name.Size = new System.Drawing.Size(133, 20);
            this.txt_Name.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(316, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Name";
            // 
            // btn_showPlayers
            // 
            this.btn_showPlayers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_showPlayers.Location = new System.Drawing.Point(16, 65);
            this.btn_showPlayers.Name = "btn_showPlayers";
            this.btn_showPlayers.Size = new System.Drawing.Size(126, 23);
            this.btn_showPlayers.TabIndex = 5;
            this.btn_showPlayers.Text = "Show Players";
            this.btn_showPlayers.UseVisualStyleBackColor = true;
            this.btn_showPlayers.Click += new System.EventHandler(this.btn_showPlayers_Click);
            // 
            // btn_Edit
            // 
            this.btn_Edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Edit.Location = new System.Drawing.Point(148, 65);
            this.btn_Edit.Name = "btn_Edit";
            this.btn_Edit.Size = new System.Drawing.Size(130, 23);
            this.btn_Edit.TabIndex = 6;
            this.btn_Edit.Text = "Change Name";
            this.btn_Edit.UseVisualStyleBackColor = true;
            this.btn_Edit.Click += new System.EventHandler(this.btn_Edit_Click);
            // 
            // btn_Next
            // 
            this.btn_Next.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Next.Location = new System.Drawing.Point(428, 329);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(75, 23);
            this.btn_Next.TabIndex = 7;
            this.btn_Next.Text = "Next";
            this.btn_Next.UseVisualStyleBackColor = true;
            this.btn_Next.Click += new System.EventHandler(this.btn_Next_Click);
            // 
            // btn_back
            // 
            this.btn_back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.Location = new System.Drawing.Point(319, 329);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(103, 23);
            this.btn_back.TabIndex = 8;
            this.btn_back.Text = "Previous";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(284, 65);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(119, 23);
            this.btn_delete.TabIndex = 9;
            this.btn_delete.Text = "Delete Player";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_selectPlayer
            // 
            this.btn_selectPlayer.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btn_selectPlayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_selectPlayer.Location = new System.Drawing.Point(16, 329);
            this.btn_selectPlayer.Name = "btn_selectPlayer";
            this.btn_selectPlayer.Size = new System.Drawing.Size(112, 23);
            this.btn_selectPlayer.TabIndex = 10;
            this.btn_selectPlayer.Text = "Select..";
            this.btn_selectPlayer.UseVisualStyleBackColor = true;
            this.btn_selectPlayer.Click += new System.EventHandler(this.btn_selectPlayer_Click);
            // 
            // lbl_Id
            // 
            this.lbl_Id.AutoSize = true;
            this.lbl_Id.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_Id.ForeColor = System.Drawing.SystemColors.Control;
            this.lbl_Id.Location = new System.Drawing.Point(490, 372);
            this.lbl_Id.Name = "lbl_Id";
            this.lbl_Id.Size = new System.Drawing.Size(13, 13);
            this.lbl_Id.TabIndex = 11;
            this.lbl_Id.Text = "0";
            // 
            // PlayerSelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 397);
            this.Controls.Add(this.lbl_Id);
            this.Controls.Add(this.btn_selectPlayer);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.btn_Next);
            this.Controls.Add(this.btn_Edit);
            this.Controls.Add(this.btn_showPlayers);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_Name);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dg_Players);
            this.Controls.Add(this.lbl_blank);
            this.Name = "PlayerSelect";
            this.Text = "PlayerSelect";
            ((System.ComponentModel.ISupportInitialize)(this.dg_Players)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_blank;
        private System.Windows.Forms.DataGridView dg_Players;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txt_Name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_showPlayers;
        private System.Windows.Forms.Button btn_Edit;
        private System.Windows.Forms.Button btn_Next;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Button btn_delete;
        public System.Windows.Forms.Button btn_selectPlayer;
        private System.Windows.Forms.Label lbl_Id;
    }
}