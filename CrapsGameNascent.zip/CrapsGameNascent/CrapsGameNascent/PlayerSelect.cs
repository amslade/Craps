﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CrapsGameNascent
{
    public partial class PlayerSelect : Form
    {
        DataSet ds = new DataSet();
        SqlConnection cs = new SqlConnection("Data Source = coderfoundry.cloudapp.net,55555;Initial Catalog=spridgen-fastfood;user id=spridgen;password=1qa2ws#ED$RF5tg6yh; MultipleActiveResultSets=true;Integrated Security = false");
        SqlDataAdapter da = new SqlDataAdapter();

        BindingSource tblNamesBS = new BindingSource();

        public string myPlayer;

        public string playerS
        {
            get { return myPlayer; }
            set { myPlayer = value; }
        }
        public PlayerSelect()
        {
            InitializeComponent();
        }

        private void PlayerSelect_Load(object sender, EventArgs e)
        {
            da.SelectCommand = new SqlCommand("SELECT * FROM Player", cs);
            da.Fill(ds);

            dg_Players.DataSource = ds.Tables[0];

            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            da.InsertCommand = new SqlCommand("INSERT INTO Player VALUES(@NAME)", cs);
            da.InsertCommand.Parameters.Add("@NAME", SqlDbType.VarChar).Value = txt_Name.Text;


            cs.Open();
            da.InsertCommand.ExecuteNonQuery();
            cs.Close();
            dg_Players.Update();
            dg_Players.Refresh();
        }

        private void btn_showPlayers_Click(object sender, EventArgs e)
        {
            if (lbl_Id.Text != "0")
            {
                da.SelectCommand = new SqlCommand("SELECT * FROM Player", cs);

                ds.Clear();

                da.Fill(ds);

                dg_Players.DataSource = ds.Tables[0];

                tblNamesBS.DataSource = ds.Tables[0];
            }
            else
            {
                

                MessageBox.Show("Please use the 'Next' and 'Previous' buttons to ensure the correct player is chosen.", "Heads Up", MessageBoxButtons.OK);
                da.SelectCommand = new SqlCommand("SELECT * FROM Player", cs);

                ds.Clear();

                da.Fill(ds);

                dg_Players.DataSource = ds.Tables[0];

                tblNamesBS.DataSource = ds.Tables[0];

                txt_Name.DataBindings.Clear();
                txt_Name.DataBindings.Add(new Binding("Text", tblNamesBS, "Name"));
                lbl_Id.DataBindings.Add(new Binding("Text", tblNamesBS, "Id"));
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_Edit_Click(object sender, EventArgs e)
        {
            int x;

            da.UpdateCommand = new SqlCommand("UPDATE Player SET NAME = @NAME WHERE ID = @ID", cs);
            da.UpdateCommand.Parameters.Add("@NAME", SqlDbType.VarChar).Value = txt_Name.Text;
            da.UpdateCommand.Parameters.Add("@ID", SqlDbType.Int).Value = ds.Tables[0].Rows[tblNamesBS.Position][0];

            cs.Open();
            x = da.UpdateCommand.ExecuteNonQuery();
            cs.Close();
            
            if (x >= 1)
            {
                MessageBox.Show("Player has been updated.");

            }
        }

        private void btn_Next_Click(object sender, EventArgs e)
        {
            tblNamesBS.MoveNext();
            dgUpdate();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            tblNamesBS.MovePrevious();
            dgUpdate();
        }

        private void dgUpdate()
        {
            dg_Players.ClearSelection();
            dg_Players.Rows[tblNamesBS.Position].Selected = true;
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DialogResult dr;

            dr = MessageBox.Show("Delete player?\nAll game history for this player will be deleted as well and there will be no bringing a player back once it is deleted.", "Confirm Deletion", MessageBoxButtons.YesNoCancel);

            if (dr == DialogResult.Yes)
            {

                da.DeleteCommand = new SqlCommand("DELETE FROM Player WHERE ID = @ID", cs);
                da.DeleteCommand.Parameters.Add("@ID", SqlDbType.Int).Value = ds.Tables[0].Rows[tblNamesBS.Position][0];

                cs.Open();
                da.DeleteCommand.ExecuteNonQuery();
                cs.Close();

                da.DeleteCommand = new SqlCommand("DELETE FROM PastGames WHERE PlayerId = @ID", cs);
                da.DeleteCommand.Parameters.Add("@ID", SqlDbType.Int).Value = ds.Tables[0].Rows[tblNamesBS.Position][0];

                cs.Open();
                da.DeleteCommand.ExecuteNonQuery();
                cs.Close();



                ds.Clear();
                da.Fill(ds);
            }
            else
            {
                MessageBox.Show("Deletion canceled");

            }
        }

        public string Send
        {
            get
            {
                return txt_Name.Text;
            }
        }

        public string sendId
        {
            get
            {
                return lbl_Id.Text;
            }
        }

        public void btn_selectPlayer_Click(object sender, EventArgs e)
        {
            
            
        }
    }
}
