﻿namespace CrapsGameNascent
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_rollDice = new System.Windows.Forms.Button();
            this.lbl_displayResults = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.lbl_Count = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_playerId = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_point = new System.Windows.Forms.Label();
            this.btn_playerSel = new System.Windows.Forms.Button();
            this.lbl_dice2 = new System.Windows.Forms.Label();
            this.lbl_dice1 = new System.Windows.Forms.Label();
            this.dg_History = new System.Windows.Forms.DataGridView();
            this.txt_selPlayer = new System.Windows.Forms.TextBox();
            this.btn_clearGames = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lbl_pID = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_tot = new System.Windows.Forms.Label();
            this.lbl_LR = new System.Windows.Forms.Label();
            this.lbl_lastRoll = new System.Windows.Forms.Label();
            this.lbl_blank = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dg_History)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_rollDice
            // 
            this.btn_rollDice.Location = new System.Drawing.Point(326, 379);
            this.btn_rollDice.Name = "btn_rollDice";
            this.btn_rollDice.Size = new System.Drawing.Size(97, 37);
            this.btn_rollDice.TabIndex = 2;
            this.btn_rollDice.Text = "New Roll";
            this.btn_rollDice.UseVisualStyleBackColor = true;
            this.btn_rollDice.Click += new System.EventHandler(this.btn_rollDice_Click);
            // 
            // lbl_displayResults
            // 
            this.lbl_displayResults.BackColor = System.Drawing.Color.White;
            this.lbl_displayResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_displayResults.Location = new System.Drawing.Point(57, 352);
            this.lbl_displayResults.Name = "lbl_displayResults";
            this.lbl_displayResults.Size = new System.Drawing.Size(231, 164);
            this.lbl_displayResults.TabIndex = 3;
            this.lbl_displayResults.Text = "Roll The Dice";
            this.lbl_displayResults.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label.Location = new System.Drawing.Point(15, 166);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(129, 25);
            this.label.TabIndex = 5;
            this.label.Text = "Roll Count:";
            this.label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Count
            // 
            this.lbl_Count.AutoSize = true;
            this.lbl_Count.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Count.Location = new System.Drawing.Point(145, 167);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Size = new System.Drawing.Size(21, 24);
            this.lbl_Count.TabIndex = 6;
            this.lbl_Count.Text = "0";
            this.lbl_Count.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(515, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 25);
            this.label1.TabIndex = 7;
            this.label1.Text = "Player:";
            // 
            // lbl_playerId
            // 
            this.lbl_playerId.AutoSize = true;
            this.lbl_playerId.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_playerId.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_playerId.Location = new System.Drawing.Point(254, 112);
            this.lbl_playerId.Name = "lbl_playerId";
            this.lbl_playerId.Size = new System.Drawing.Size(0, 24);
            this.lbl_playerId.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(16, 207);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 24);
            this.label3.TabIndex = 9;
            this.label3.Text = "Point:";
            // 
            // lbl_point
            // 
            this.lbl_point.AutoSize = true;
            this.lbl_point.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_point.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_point.Location = new System.Drawing.Point(145, 207);
            this.lbl_point.Name = "lbl_point";
            this.lbl_point.Size = new System.Drawing.Size(21, 24);
            this.lbl_point.TabIndex = 10;
            this.lbl_point.Text = "0";
            // 
            // btn_playerSel
            // 
            this.btn_playerSel.Location = new System.Drawing.Point(739, 12);
            this.btn_playerSel.Name = "btn_playerSel";
            this.btn_playerSel.Size = new System.Drawing.Size(33, 27);
            this.btn_playerSel.TabIndex = 13;
            this.btn_playerSel.Text = "...";
            this.btn_playerSel.UseVisualStyleBackColor = true;
            this.btn_playerSel.Click += new System.EventHandler(this.btn_playerSel_Click);
            // 
            // lbl_dice2
            // 
            this.lbl_dice2.Image = global::CrapsGameNascent.Properties.Resources._1;
            this.lbl_dice2.Location = new System.Drawing.Point(323, 175);
            this.lbl_dice2.Name = "lbl_dice2";
            this.lbl_dice2.Size = new System.Drawing.Size(100, 107);
            this.lbl_dice2.TabIndex = 1;
            // 
            // lbl_dice1
            // 
            this.lbl_dice1.Image = global::CrapsGameNascent.Properties.Resources._1;
            this.lbl_dice1.Location = new System.Drawing.Point(188, 175);
            this.lbl_dice1.Name = "lbl_dice1";
            this.lbl_dice1.Size = new System.Drawing.Size(100, 107);
            this.lbl_dice1.TabIndex = 0;
            // 
            // dg_History
            // 
            this.dg_History.BackgroundColor = System.Drawing.Color.Green;
            this.dg_History.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_History.Location = new System.Drawing.Point(491, 176);
            this.dg_History.Name = "dg_History";
            this.dg_History.ReadOnly = true;
            this.dg_History.Size = new System.Drawing.Size(281, 299);
            this.dg_History.TabIndex = 15;
            this.dg_History.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // txt_selPlayer
            // 
            this.txt_selPlayer.Location = new System.Drawing.Point(607, 112);
            this.txt_selPlayer.Name = "txt_selPlayer";
            this.txt_selPlayer.ReadOnly = true;
            this.txt_selPlayer.Size = new System.Drawing.Size(165, 20);
            this.txt_selPlayer.TabIndex = 16;
            // 
            // btn_clearGames
            // 
            this.btn_clearGames.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clearGames.Location = new System.Drawing.Point(491, 147);
            this.btn_clearGames.Name = "btn_clearGames";
            this.btn_clearGames.Size = new System.Drawing.Size(154, 23);
            this.btn_clearGames.TabIndex = 17;
            this.btn_clearGames.Text = "Clear Game History";
            this.btn_clearGames.UseVisualStyleBackColor = true;
            this.btn_clearGames.Click += new System.EventHandler(this.btn_clearGames_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(651, 147);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = "Show Games";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // lbl_pID
            // 
            this.lbl_pID.AutoSize = true;
            this.lbl_pID.ForeColor = System.Drawing.Color.Green;
            this.lbl_pID.Location = new System.Drawing.Point(12, 9);
            this.lbl_pID.Name = "lbl_pID";
            this.lbl_pID.Size = new System.Drawing.Size(0, 13);
            this.lbl_pID.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(17, 285);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 24);
            this.label2.TabIndex = 20;
            this.label2.Text = "Total:";
            // 
            // lbl_tot
            // 
            this.lbl_tot.AutoSize = true;
            this.lbl_tot.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tot.ForeColor = System.Drawing.SystemColors.Control;
            this.lbl_tot.Location = new System.Drawing.Point(145, 285);
            this.lbl_tot.Name = "lbl_tot";
            this.lbl_tot.Size = new System.Drawing.Size(21, 24);
            this.lbl_tot.TabIndex = 21;
            this.lbl_tot.Text = "0";
            // 
            // lbl_LR
            // 
            this.lbl_LR.AutoSize = true;
            this.lbl_LR.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_LR.ForeColor = System.Drawing.SystemColors.Control;
            this.lbl_LR.Location = new System.Drawing.Point(17, 244);
            this.lbl_LR.Name = "lbl_LR";
            this.lbl_LR.Size = new System.Drawing.Size(95, 24);
            this.lbl_LR.TabIndex = 22;
            this.lbl_LR.Text = "Last Roll:";
            // 
            // lbl_lastRoll
            // 
            this.lbl_lastRoll.AutoSize = true;
            this.lbl_lastRoll.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_lastRoll.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_lastRoll.Location = new System.Drawing.Point(145, 244);
            this.lbl_lastRoll.Name = "lbl_lastRoll";
            this.lbl_lastRoll.Size = new System.Drawing.Size(21, 24);
            this.lbl_lastRoll.TabIndex = 23;
            this.lbl_lastRoll.Text = "0";
            // 
            // lbl_blank
            // 
            this.lbl_blank.AutoSize = true;
            this.lbl_blank.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_blank.ForeColor = System.Drawing.SystemColors.Control;
            this.lbl_blank.Location = new System.Drawing.Point(529, 59);
            this.lbl_blank.Name = "lbl_blank";
            this.lbl_blank.Size = new System.Drawing.Size(243, 24);
            this.lbl_blank.TabIndex = 24;
            this.lbl_blank.Text = "Show Game History For: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(139, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 39);
            this.label4.TabIndex = 25;
            this.label4.Text = "Craps";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbl_blank);
            this.Controls.Add(this.lbl_lastRoll);
            this.Controls.Add(this.lbl_LR);
            this.Controls.Add(this.lbl_tot);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_pID);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_clearGames);
            this.Controls.Add(this.txt_selPlayer);
            this.Controls.Add(this.dg_History);
            this.Controls.Add(this.btn_playerSel);
            this.Controls.Add(this.lbl_point);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl_playerId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_Count);
            this.Controls.Add(this.label);
            this.Controls.Add(this.lbl_displayResults);
            this.Controls.Add(this.btn_rollDice);
            this.Controls.Add(this.lbl_dice2);
            this.Controls.Add(this.lbl_dice1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximumSize = new System.Drawing.Size(800, 600);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "Form1";
            this.Text = "Craps";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_History)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_dice1;
        private System.Windows.Forms.Label lbl_dice2;
        private System.Windows.Forms.Button btn_rollDice;
        private System.Windows.Forms.Label lbl_displayResults;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_playerId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_playerSel;
        private System.Windows.Forms.DataGridView dg_History;
        private System.Windows.Forms.TextBox txt_selPlayer;
        private System.Windows.Forms.Button btn_clearGames;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbl_pID;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label lbl_Count;
        public System.Windows.Forms.Label lbl_point;
        public System.Windows.Forms.Label lbl_tot;
        private System.Windows.Forms.Label lbl_LR;
        public System.Windows.Forms.Label lbl_lastRoll;
        private System.Windows.Forms.Label lbl_blank;
        private System.Windows.Forms.Label label4;
    }
}

