﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
#endregion

namespace CrapsGameNascent
{

    public partial class Form1 : Form
    {
        DataSet ds = new DataSet();
        SqlConnection cs = new SqlConnection("Data Source = coderfoundry.cloudapp.net,55555;Initial Catalog=spridgen-fastfood;user id=spridgen;password=1qa2ws#ED$RF5tg6yh; MultipleActiveResultSets=true;Integrated Security = false");
        SqlDataAdapter da = new SqlDataAdapter();

        BindingSource tblNamesBS = new BindingSource();

        #region Declaration

        Image[] diceImages;
        int[] dice;
        int[] diceResults;
        Random rand;
        int counter;

        #endregion

        #region Initialization
        public Form1()
        {
            InitializeComponent();
        }

        private PlayerSelect pS;
        private void Form1_Load(object sender, EventArgs e)
        {
            bool playerSelected = false;

            pS = new PlayerSelect();
            pS.ShowDialog();

            txt_selPlayer.Clear();
            txt_selPlayer.Text = pS.Send;

            lbl_pID.Text = pS.sendId;



            diceImages = new Image[7];
            diceImages[0] = Properties.Resources._0;
            diceImages[1] = Properties.Resources._1;
            diceImages[2] = Properties.Resources._2;
            diceImages[3] = Properties.Resources._3;
            diceImages[4] = Properties.Resources._4;
            diceImages[5] = Properties.Resources._5;
            diceImages[6] = Properties.Resources._6;


            dice = new int[2] { 0, 0 };

            diceResults = new int[6] { 0, 0, 0, 0, 0, 0 };

            rand = new Random();
        }
        #endregion

        #region Methods

        private void btn_rollDice_Click(object sender, EventArgs e)
        {
            RollDice();

            if (counter >= 1)
                ContGame();
            else
                NewGame();

            //ResetResults();
        }



        public void RollDice()
        {

            for (int i = 0; i < dice.Length; i++)
            {
                dice[i] = rand.Next(1, 6 + 1);

                switch (dice[i])
                {
                    case 1:
                        diceResults[0]++;
                        break;
                    case 2:
                        diceResults[1]++;
                        break;
                    case 3:
                        diceResults[2]++;
                        break;
                    case 4:
                        diceResults[3]++;
                        break;
                    case 5:
                        diceResults[4]++;
                        break;
                    case 6:
                        diceResults[5]++;
                        break;
                }


            }

            lbl_dice1.Image = diceImages[dice[0]];
            lbl_dice2.Image = diceImages[dice[1]];
        }

        #region if Method
        public void ContGame()
        {

            //Boolean values are called upon when GetResults is called
            bool sevenResult = false;
            bool loseResult = false;
            bool pointResult = false;
            

            int total = dice[0] + dice[1];

            lbl_lastRoll.Text = total.ToString();



            //Use the "For Loop" statement to display the results
            for (int i = 0; i < diceResults.Length; i++)
            {

                if (total == 7 || total == 11)
                    sevenResult = true;
                else if (total == 2 || total == 3 || total == 12)
                    loseResult = true;
                else if (total == 4 || total == 5 || total == 6 || total == 8 || total == 9 || total == 10)
                    pointResult = true;
            }


            if (sevenResult)
            {
                counter++;
                lbl_Count.Text = counter.ToString();
                lbl_displayResults.Text = "You rolled " + total + ". You lose!";
                var sumtot = total + lbl_lastRoll.Text;
                lbl_lastRoll.Text = total.ToString();
                lbl_tot.Text = sumtot.ToString();
                lbl_Count.Text = counter.ToString();
                #region SQL Command
                da.InsertCommand = new SqlCommand("INSERT INTO PastGames VALUES(@PlayerId, @Score, @W, @L, @Point)", cs);
                da.InsertCommand.Parameters.Add("@PlayerId", SqlDbType.Int).Value = lbl_pID.Text;
                da.InsertCommand.Parameters.Add("@Score", SqlDbType.VarChar).Value = lbl_Count.Text;
                da.InsertCommand.Parameters.Add("@W", SqlDbType.VarChar).Value = "";
                da.InsertCommand.Parameters.Add("@L", SqlDbType.VarChar).Value = "L";
                da.InsertCommand.Parameters.Add("@Point", SqlDbType.VarChar).Value = lbl_point.Text;

                cs.Open();
                da.InsertCommand.ExecuteNonQuery();
                cs.Close();
                
                #endregion
                lbl_lastRoll.Text = "0";
                lbl_tot.Text = "0";
                lbl_point.Text = "0";
                counter = 0;
                lbl_Count.Text = counter.ToString();
                


            }
            else if (loseResult)
            {
                counter++;
                lbl_Count.Text = counter.ToString();
                if (counter <= 1)
                {
                    lbl_displayResults.Text = "You rolled " + total + ". You lose!";
                    lbl_lastRoll.Text = total.ToString();
                    lbl_Count.Text = counter.ToString();
                    #region SQL Command
                    da.InsertCommand = new SqlCommand("INSERT INTO PastGames VALUES(@PlayerId, @Score, @W, @L, @Point)", cs);
                    da.InsertCommand.Parameters.Add("@PlayerId", SqlDbType.Int).Value = lbl_pID.Text;
                    da.InsertCommand.Parameters.Add("@Score", SqlDbType.VarChar).Value = lbl_Count.Text;
                    da.InsertCommand.Parameters.Add("@W", SqlDbType.VarChar).Value = "";
                    da.InsertCommand.Parameters.Add("@L", SqlDbType.VarChar).Value = "L";
                    da.InsertCommand.Parameters.Add("@Point", SqlDbType.VarChar).Value = lbl_point.Text;

                    cs.Open();
                    da.InsertCommand.ExecuteNonQuery();
                    cs.Close();
                    
                    #endregion
                    lbl_lastRoll.Text = "0";
                    lbl_tot.Text = "0";
                    lbl_point.Text = "0";
                    counter = 0;
                    lbl_Count.Text = counter.ToString();
                    
                }
                else
                {
                    counter++;
                    lbl_lastRoll.Text = total.ToString();
                    lbl_displayResults.Text = "You rolled " + total + ". Roll again.";

                }
            }
            else if (pointResult)
            {
                counter++;
                lbl_Count.Text = counter.ToString();
                lbl_displayResults.Text = total + " is your point! Roll again.";
                int ptVal = total;
                lbl_point.Text = ptVal.ToString();
                lbl_lastRoll.Text = total.ToString();
            }
        }
        #endregion

        #region else Method
        public void NewGame()
        {
            //Boolean values are called upon when GetResults is called
            bool sevenResult = false;
            bool loseResult = false;
            bool pointResult = false;
            

            int total = dice[0] + dice[1];

            lbl_lastRoll.Text = total.ToString();





            //Use the "For Loop" statement to display the results


            for (int i = 0; i < diceResults.Length; i++)
            {

                if (total == 7 || total == 11)
                    sevenResult = true;
                else if (total == 2 || total == 3 || total == 12)
                    loseResult = true;
                else if (total == 4 || total == 5 || total == 6 || total == 8 || total == 9 || total == 10)
                    pointResult = true;
            }


            if (sevenResult)
            {
                counter++;
                lbl_Count.Text = counter.ToString();
                lbl_displayResults.Text = "You rolled " + total + ". You win!";
                lbl_Count.Text = counter.ToString();
                #region SQL Command
                da.InsertCommand = new SqlCommand("INSERT INTO PastGames VALUES(@PlayerId, @Score, @W, @L, @Point)", cs);
                da.InsertCommand.Parameters.Add("@PlayerId", SqlDbType.Int).Value = lbl_pID.Text;
                da.InsertCommand.Parameters.Add("@Score", SqlDbType.VarChar).Value = lbl_lastRoll.Text;
                da.InsertCommand.Parameters.Add("@W", SqlDbType.VarChar).Value = "W";
                da.InsertCommand.Parameters.Add("@L", SqlDbType.VarChar).Value = "";
                da.InsertCommand.Parameters.Add("@Point", SqlDbType.VarChar).Value = lbl_point.Text;

                cs.Open();
                da.InsertCommand.ExecuteNonQuery();
                cs.Close();
                
                #endregion
                int ptVal = 0;
                lbl_point.Text = ptVal.ToString();
                counter = 0;
                lbl_Count.Text = counter.ToString();
                


            }
            else if (loseResult)
            {
                counter++;
                lbl_Count.Text = counter.ToString();
                if (counter <= 1)
                {
                    lbl_displayResults.Text = "You rolled " + total + ". You lose!";
                    lbl_lastRoll.Text = total.ToString();
                    lbl_Count.Text = counter.ToString();
                    #region SQL Command
                    da.InsertCommand = new SqlCommand("INSERT INTO PastGames VALUES(@PlayerId, @Score, @W, @L, @Point)", cs);
                    da.InsertCommand.Parameters.Add("@PlayerId", SqlDbType.Int).Value = lbl_pID.Text;
                    da.InsertCommand.Parameters.Add("@Score", SqlDbType.VarChar).Value = lbl_lastRoll.Text;
                    da.InsertCommand.Parameters.Add("@W", SqlDbType.VarChar).Value = "";
                    da.InsertCommand.Parameters.Add("@L", SqlDbType.VarChar).Value = "L";
                    da.InsertCommand.Parameters.Add("@Point", SqlDbType.VarChar).Value = lbl_point.Text;

                    cs.Open();
                    da.InsertCommand.ExecuteNonQuery();
                    cs.Close();
                    
                    #endregion
                    lbl_lastRoll.Text = "0";
                    lbl_tot.Text = "0";
                    lbl_point.Text = "0";
                    counter = 0;
                    lbl_Count.Text = counter.ToString();
                    
                }
                else
                {
                    counter++;
                    int ptVal = total;
                    lbl_point.Text = total.ToString();
                    lbl_displayResults.Text = "You rolled " + total + ". Roll again.";

                }
            }
            else if (pointResult)
            {
                counter++;
                lbl_Count.Text = counter.ToString();
                lbl_displayResults.Text = total + " is your point! Roll again.";
                int ptVal = total;
                lbl_point.Text = total.ToString();
            }
        }
        #endregion

       
        #region RBin
        private void ResetResults()
        {
            for (int i = 0; i < diceResults.Length; i++)
                diceResults[i] = 0;
        }

        public void btn_Reset_Click(object sender, EventArgs e)
        {

        }




        public void btn_rollAgain_Click(object sender, EventArgs e)
        {



        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        public void lbl_btnRollAgain_Click(object sender, EventArgs e)
        {

        }

        #endregion

        private void btn_playerSel_Click(object sender, EventArgs e)
        {
            var myForm = new PlayerSelect();
            myForm.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            da.SelectCommand = new SqlCommand("SELECT * FROM Player p JOIN PastGames pg on p.Id = pg.PlayerId WHERE @Id = p.Id", cs);
            da.SelectCommand.Parameters.Add("@Id", SqlDbType.Int).Value = lbl_pID.Text;
            

            ds.Clear();

            da.Fill(ds);

            dg_History.DataSource = ds.Tables[0];

            tblNamesBS.DataSource = ds.Tables[0];

            

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_clearGames_Click(object sender, EventArgs e)
        {
            DialogResult dr;

            if (lbl_pID.Text == null)
            {
                MessageBox.Show("You must choose a player first");
            }
            else
            {
                dr = MessageBox.Show("Delete game history?\nThis can't be undone.", "Confirm Deletion", MessageBoxButtons.YesNoCancel);

                if (dr == DialogResult.Yes)
                {

                    da.DeleteCommand = new SqlCommand("DELETE from PastGames WHERE PlayerId = @PlayerId", cs);
                    da.DeleteCommand.Parameters.Add("@PlayerId", SqlDbType.Int).Value = lbl_pID.Text;

                    cs.Open();
                    da.DeleteCommand.ExecuteNonQuery();
                    cs.Close();

                    ds.Clear();
                    da.Fill(ds);
                }
                else
                {
                    MessageBox.Show("Deletion canceled");

                }
            }
        }
    }

    #endregion
}
