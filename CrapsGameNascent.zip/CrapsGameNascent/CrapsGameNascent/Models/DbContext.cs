﻿using CrapsGameNascent.Models;
using CrapsGameNascent.Models.CustomModels;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrapsGameNascent
{
    public class DbContext
    {
        public static DbContext Create()
        {
            return new DbContext();
        }

        public DbSet<Game> Games { get; set; }
        public DbSet<Player>  Players { get; set; }
        
    }
}
