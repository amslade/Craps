﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrapsGameNascent.Models.CustomModels
{
    public class Game
    {
        public int Id { get; set; }
        public int? Sum { get; set; }
        public bool Complete { get; set; }
        public virtual Player Player { get; set; }


    }
}
